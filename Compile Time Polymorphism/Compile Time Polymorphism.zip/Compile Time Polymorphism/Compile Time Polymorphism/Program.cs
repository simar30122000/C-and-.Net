﻿using System;
namespace Compile_Time_Polymorphism
{
    class Shape
    {
        protected double a, b,c;
        //public Shape(double x,double y)
        //{
        //    a = x;
        //    b = y;
        //    }

        public double Area(double a,double b)
        {
            this.a = a;
            this.b = b;
            return a * b;
        }
        public double Area(double a)
        {
            this.a = a;
            return (Math.PI * a * a);
        }
        public double Area(double a, double b,double c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
            double sp = (a + b + c)/2;
            
            return Math.Sqrt(sp*(sp-a)*(sp-b)*(sp-c));
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b=2;
            double c;
            Shape s = new Shape();
            
            Console.WriteLine("Which Shape's Area is to be found\n1-Rectangle\n2-Triangle\n3-Circle");
            int i = int.Parse(Console.ReadLine());
            switch (i)
            {
                case 1:
                    {
                        Console.WriteLine("Enter Length");
                        a = double.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Breadth");
                        b = double.Parse(Console.ReadLine());
                        Console.WriteLine(s.Area(a, b)+" is the area");
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("Enter side 1");
                        a = double.Parse(Console.ReadLine());
                        Console.WriteLine("Enter side 2");
                        b = double.Parse(Console.ReadLine());
                        Console.WriteLine("Enter side 3");
                        c = double.Parse(Console.ReadLine());
                        Console.WriteLine(s.Area(a,c,b) + " is the area");

                        break;
                    }
                case 3:
                    {
                        Console.WriteLine("Enter Radius");
                        a = double.Parse(Console.ReadLine());
                        Console.WriteLine(s.Area(a) + " is the area");

                        break;
                    }
            }
        }
    }
}
