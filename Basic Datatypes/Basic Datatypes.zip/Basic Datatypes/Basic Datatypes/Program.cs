﻿using System;

namespace Basic_Datatypes
{
    class Program
    {
        static void Main(string[] args)
        {
            int sq = int.Parse(Console.ReadLine());
            Console.WriteLine(sq * sq);
        }
    }
}
